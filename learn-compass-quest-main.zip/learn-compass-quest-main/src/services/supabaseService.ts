import { supabase } from "@/integrations/supabase/client";

// ===================== Generic Error Handler =====================
function handleError(context: string, error: any): never {
  console.error(`[DB Error] ${context}:`, error);
  throw new Error(error?.message || `Erro em ${context}`);
}

// ===================== Assessments =====================
export const assessmentService = {
  async list() {
    const { data, error } = await supabase
      .from("assessments")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) handleError("listar avaliações", error);
    return data!;
  },

  async getById(id: string) {
    const { data, error } = await supabase
      .from("assessments")
      .select("*")
      .eq("id", id)
      .single();
    if (error) handleError("buscar avaliação", error);
    return data!;
  },

  async create(assessment: { title: string; year: string; subject: string; created_by?: string }) {
    const { data, error } = await supabase
      .from("assessments")
      .insert(assessment)
      .select()
      .single();
    if (error) handleError("criar avaliação", error);
    return data!;
  },

  async updateStatus(id: string, status: string) {
    const { error } = await supabase
      .from("assessments")
      .update({ status })
      .eq("id", id);
    if (error) handleError("atualizar status", error);
  },

  async remove(id: string) {
    const { error } = await supabase
      .from("assessments")
      .delete()
      .eq("id", id);
    if (error) handleError("remover avaliação", error);
  },
};

// ===================== Assessment Questions =====================
export const assessmentQuestionService = {
  async listByAssessment(assessmentId: string) {
    const { data, error } = await supabase
      .from("assessment_questions")
      .select("*")
      .eq("assessment_id", assessmentId)
      .order("position");
    if (error) handleError("listar questões da avaliação", error);
    return data!;
  },

  async bulkInsert(questions: Array<{
    assessment_id: string;
    statement: string;
    option_a: string;
    option_b: string;
    option_c: string;
    option_d: string;
    correct_answer: string;
    skill?: string;
    position?: number;
    question_id?: string | null;
  }>) {
    const { error } = await supabase
      .from("assessment_questions")
      .insert(questions);
    if (error) handleError("inserir questões", error);
  },

  async removeByAssessment(assessmentId: string) {
    const { error } = await supabase
      .from("assessment_questions")
      .delete()
      .eq("assessment_id", assessmentId);
    if (error) handleError("remover questões", error);
  },
};

// ===================== Questions (Bank) =====================
export const questionService = {
  async list() {
    const { data, error } = await supabase
      .from("questions")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) handleError("listar questões", error);
    return data!;
  },

  async create(question: {
    statement: string;
    option_a: string;
    option_b: string;
    option_c: string;
    option_d: string;
    correct_answer: string;
    subject: string;
    year: string;
    skill?: string;
    created_by?: string;
  }) {
    const { data, error } = await supabase
      .from("questions")
      .insert(question)
      .select()
      .single();
    if (error) handleError("criar questão", error);
    return data!;
  },

  async update(id: string, updates: Record<string, any>) {
    const { error } = await supabase
      .from("questions")
      .update(updates)
      .eq("id", id);
    if (error) handleError("atualizar questão", error);
  },

  async remove(id: string) {
    const { error } = await supabase
      .from("questions")
      .delete()
      .eq("id", id);
    if (error) handleError("remover questão", error);
  },
};

// ===================== Students =====================
export const studentService = {
  async list() {
    const { data, error } = await supabase
      .from("students")
      .select("*")
      .order("name");
    if (error) handleError("listar alunos", error);
    return data!;
  },

  async create(student: {
    name: string;
    enrollment_number: string;
    school?: string;
    class?: string;
    school_year?: string;
    created_by?: string;
  }) {
    const { data, error } = await supabase
      .from("students")
      .insert(student)
      .select()
      .single();
    if (error) handleError("cadastrar aluno", error);
    return data!;
  },

  async bulkInsert(students: Array<{
    name: string;
    enrollment_number: string;
    school?: string;
    class?: string;
    school_year?: string;
  }>) {
    const { error } = await supabase
      .from("students")
      .insert(students);
    if (error) handleError("importar alunos", error);
  },
};

// ===================== Profiles & Roles =====================
export const profileService = {
  async list() {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .order("name");
    if (error) handleError("listar perfis", error);
    return data!;
  },

  async getByUserId(userId: string) {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("user_id", userId)
      .single();
    if (error) handleError("buscar perfil", error);
    return data!;
  },

  async updateName(userId: string, name: string) {
    const { error } = await supabase
      .from("profiles")
      .update({ name })
      .eq("user_id", userId);
    if (error) handleError("atualizar nome", error);
  },
};

export const roleService = {
  async list() {
    const { data, error } = await supabase
      .from("user_roles")
      .select("*");
    if (error) handleError("listar cargos", error);
    return data!;
  },

  async updateRole(userId: string, role: "admin" | "coordenador" | "professor") {
    const { error } = await supabase
      .from("user_roles")
      .update({ role })
      .eq("user_id", userId);
    if (error) handleError("atualizar cargo", error);
  },
};

// ===================== BNCC Skills =====================
export const bnccSkillService = {
  async list(filters?: { subject?: string; year?: string }) {
    let query = supabase.from("bncc_skills").select("*").order("code");
    if (filters?.subject) query = query.eq("subject", filters.subject);
    if (filters?.year) query = query.eq("year", filters.year);
    const { data, error } = await query;
    if (error) handleError("listar habilidades", error);
    return data!;
  },
};

// ===================== Assessment Releases =====================
export const releaseService = {
  async listByAssessment(assessmentId: string) {
    const { data, error } = await supabase
      .from("assessment_releases")
      .select("*")
      .eq("assessment_id", assessmentId);
    if (error) handleError("listar liberações", error);
    return data!;
  },

  async save(assessmentId: string, userIds: string[], releasedBy: string) {
    // Remove existing
    await supabase
      .from("assessment_releases")
      .delete()
      .eq("assessment_id", assessmentId);

    if (userIds.length > 0) {
      const rows = userIds.map(uid => ({
        assessment_id: assessmentId,
        user_id: uid,
        released_by: releasedBy,
      }));
      const { error } = await supabase
        .from("assessment_releases")
        .insert(rows);
      if (error) handleError("salvar liberações", error);
    }
  },
};

// ===================== Assessment Results =====================
export const resultService = {
  async listByAssessment(assessmentId: string) {
    const { data, error } = await supabase
      .from("assessment_results")
      .select("*")
      .eq("assessment_id", assessmentId);
    if (error) handleError("listar resultados", error);
    return data!;
  },

  async saveResult(result: {
    student_id: string;
    assessment_id: string;
    total_questions: number;
    correct_answers: number;
    score_percentage: number;
    started_at?: string;
    completed_at?: string;
  }) {
    const { data, error } = await supabase
      .from("assessment_results")
      .upsert(result, { onConflict: "student_id,assessment_id" })
      .select()
      .single();
    if (error) handleError("salvar resultado", error);
    return data!;
  },
};

// ===================== Student Responses =====================
export const responseService = {
  async saveResponses(responses: Array<{
    student_id: string;
    assessment_id: string;
    question_id: string;
    selected_answer: string;
    is_correct: boolean;
  }>) {
    const { error } = await supabase
      .from("student_responses")
      .upsert(responses, { onConflict: "student_id,assessment_id,question_id" });
    if (error) handleError("salvar respostas", error);
  },

  async listByStudentAssessment(studentId: string, assessmentId: string) {
    const { data, error } = await supabase
      .from("student_responses")
      .select("*")
      .eq("student_id", studentId)
      .eq("assessment_id", assessmentId);
    if (error) handleError("listar respostas", error);
    return data!;
  },
};
