import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type AppRole = Database["public"]["Enums"]["app_role"];

export interface ManagedUser {
  user_id: string;
  name: string;
  email: string | null;
  role: AppRole;
}

type ManageUsersPayload =
  | { action: "list" }
  | { action: "create"; email: string; password: string; name: string; role: AppRole }
  | { action: "update"; user_id: string; name: string; email?: string }
  | { action: "delete"; user_id: string }
  | { action: "set-role"; user_id: string; role: AppRole };

async function callEdgeFunction<T>(functionName: string, body?: Record<string, unknown>): Promise<T> {
  const { data: { session } } = await supabase.auth.getSession();

  if (!session?.access_token) {
    throw new Error("Sua sessão expirou. Faça login novamente.");
  }

  const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${functionName}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${session.access_token}`,
      apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
    },
    body: JSON.stringify(body ?? {}),
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new Error(data?.error || `Erro ao executar ${functionName}`);
  }

  if (data?.error) {
    throw new Error(data.error);
  }

  return data as T;
}

export const userManagementService = {
  async list() {
    const response = await callEdgeFunction<{ users: ManagedUser[] }>("manage-users", { action: "list" });
    return response.users ?? [];
  },

  async create(payload: { email: string; password: string; name: string; role: AppRole }) {
    return callEdgeFunction<{ success: boolean; user_id: string }>("manage-users", { action: "create", ...payload });
  },

  async update(payload: { user_id: string; name: string; email?: string }) {
    return callEdgeFunction<{ success: boolean }>("manage-users", { action: "update", ...payload });
  },

  async remove(userId: string) {
    return callEdgeFunction<{ success: boolean }>("manage-users", { action: "delete", user_id: userId });
  },

  async setRole(userId: string, role: AppRole) {
    return callEdgeFunction<{ success: boolean }>("manage-users", { action: "set-role", user_id: userId, role });
  },
};