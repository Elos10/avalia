import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { z } from "https://esm.sh/zod@3.24.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const RoleSchema = z.enum(["admin", "coordenador", "professor"]);

const CreatePayloadSchema = z.object({
  action: z.literal("create"),
  email: z.string().trim().email("Informe um e-mail válido"),
  password: z.string().min(6, "A senha deve ter pelo menos 6 caracteres"),
  name: z.string().trim().min(1, "Informe o nome do usuário").max(255),
  role: RoleSchema.default("professor"),
});

const UpdatePayloadSchema = z.object({
  action: z.literal("update"),
  user_id: z.string().uuid("Usuário inválido"),
  name: z.string().trim().min(1, "Informe o nome do usuário").max(255),
  email: z.union([z.string().trim().email("Informe um e-mail válido"), z.literal("")]).optional(),
});

const DeletePayloadSchema = z.object({
  action: z.literal("delete"),
  user_id: z.string().uuid("Usuário inválido"),
});

const SetRolePayloadSchema = z.object({
  action: z.literal("set-role"),
  user_id: z.string().uuid("Usuário inválido"),
  role: RoleSchema,
});

const ListPayloadSchema = z.object({
  action: z.literal("list"),
});

const PayloadSchema = z.discriminatedUnion("action", [
  CreatePayloadSchema,
  UpdatePayloadSchema,
  DeletePayloadSchema,
  SetRolePayloadSchema,
  ListPayloadSchema,
]);

async function ensureProfile(
  supabaseAdmin: ReturnType<typeof createClient>,
  userId: string,
  name: string,
  email: string | null,
) {
  const { data: updatedProfiles, error: updateProfileError } = await supabaseAdmin
    .from("profiles")
    .update({ name, email })
    .eq("user_id", userId)
    .select("id")
    .limit(1);

  if (updateProfileError) throw updateProfileError;

  if (!updatedProfiles || updatedProfiles.length === 0) {
    const { error: insertProfileError } = await supabaseAdmin
      .from("profiles")
      .insert({ user_id: userId, name, email });

    if (insertProfileError) throw insertProfileError;
  }
}

async function ensureRole(
  supabaseAdmin: ReturnType<typeof createClient>,
  userId: string,
  role: z.infer<typeof RoleSchema>,
) {
  const { data: updatedRoles, error: updateRoleError } = await supabaseAdmin
    .from("user_roles")
    .update({ role })
    .eq("user_id", userId)
    .select("id")
    .limit(1);

  if (updateRoleError) throw updateRoleError;

  if (!updatedRoles || updatedRoles.length === 0) {
    const { error: insertRoleError } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: userId, role });

    if (insertRoleError) throw insertRoleError;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!;
    const authHeader = req.headers.get("Authorization");

    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Sessão inválida. Faça login novamente." }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUser = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey);

    const {
      data: { user: caller },
      error: authError,
    } = await supabaseUser.auth.getUser();

    if (authError || !caller) {
      return new Response(JSON.stringify({ error: "Não autenticado" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: callerRoles, error: callerRolesError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", caller.id);

    if (callerRolesError) throw callerRolesError;

    const rawBody = await req.json();
    const parsedBody = PayloadSchema.safeParse(rawBody);

    if (!parsedBody.success) {
      return new Response(JSON.stringify({ error: parsedBody.error.flatten() }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const payload = parsedBody.data;
    const isAdmin = callerRoles?.some((item) => item.role === "admin");
    const isCoordinator = callerRoles?.some((item) => item.role === "coordenador");

    if (payload.action === "list") {
      if (!isAdmin && !isCoordinator) {
        return new Response(JSON.stringify({ error: "Acesso negado" }), {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const [
        { data: authUsers, error: authUsersError },
        { data: profiles, error: profilesError },
        { data: roles, error: rolesError },
      ] = await Promise.all([
        supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 }),
        supabaseAdmin.from("profiles").select("user_id, name, email"),
        supabaseAdmin.from("user_roles").select("user_id, role"),
      ]);

      if (authUsersError) throw authUsersError;
      if (profilesError) throw profilesError;
      if (rolesError) throw rolesError;

      const profileMap = new Map((profiles ?? []).map((profile) => [profile.user_id, profile]));
      const roleMap = new Map((roles ?? []).map((roleItem) => [roleItem.user_id, roleItem.role]));

      const users = (authUsers.users ?? [])
        .map((authUser) => {
          const profile = profileMap.get(authUser.id);
          const fullName = authUser.user_metadata?.full_name;
          const metadataName = authUser.user_metadata?.name;
          const fallbackName = typeof fullName === "string" && fullName.trim()
            ? fullName.trim()
            : typeof metadataName === "string" && metadataName.trim()
              ? metadataName.trim()
              : authUser.email?.split("@")[0] ?? "Usuário";

          return {
            user_id: authUser.id,
            name: profile?.name?.trim() || fallbackName,
            email: profile?.email ?? authUser.email ?? null,
            role: roleMap.get(authUser.id) ?? "professor",
          };
        })
        .sort((a, b) => a.name.localeCompare(b.name, "pt-BR", { sensitivity: "base" }));

      return new Response(JSON.stringify({ users }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!isAdmin) {
      return new Response(
        JSON.stringify({ error: "Acesso negado. Apenas administradores podem gerenciar usuários." }),
        {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    if (payload.action === "create") {
      const { email, password, name, role } = payload;

      const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { full_name: name },
      });

      if (createError) throw createError;

      const userId = newUser.user?.id;
      if (!userId) throw new Error("Não foi possível criar o usuário");

      await ensureProfile(supabaseAdmin, userId, name, email);
      await ensureRole(supabaseAdmin, userId, role);

      return new Response(JSON.stringify({ success: true, user_id: userId }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (payload.action === "update") {
      const { user_id, name, email } = payload;
      const cleanEmail = email?.trim() ? email.trim() : null;

      await ensureProfile(supabaseAdmin, user_id, name, cleanEmail);

      const { error: updateAuthError } = await supabaseAdmin.auth.admin.updateUserById(user_id, {
        ...(cleanEmail ? { email: cleanEmail } : {}),
        user_metadata: { full_name: name },
      });

      if (updateAuthError) throw updateAuthError;

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (payload.action === "set-role") {
      await ensureRole(supabaseAdmin, payload.user_id, payload.role);

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (payload.action === "delete") {
      const { error: deleteError } = await supabaseAdmin.auth.admin.deleteUser(payload.user_id);
      if (deleteError) throw deleteError;

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Ação inválida" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Erro interno ao gerenciar usuários";

    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
