
CREATE TABLE public.students (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  enrollment_number text NOT NULL,
  name text NOT NULL,
  school text NOT NULL DEFAULT '',
  class text NOT NULL DEFAULT '',
  school_year text NOT NULL DEFAULT '',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL
);

ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;

CREATE UNIQUE INDEX students_enrollment_number_idx ON public.students (enrollment_number);

CREATE POLICY "Admins can manage students" ON public.students FOR ALL TO authenticated USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Authenticated can view students" ON public.students FOR SELECT TO authenticated USING (true);
