
CREATE TABLE public.assessment_releases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id uuid NOT NULL REFERENCES public.assessments(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  released_by uuid REFERENCES auth.users(id),
  released_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(assessment_id, user_id)
);

ALTER TABLE public.assessment_releases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage releases" ON public.assessment_releases
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view own releases" ON public.assessment_releases
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
