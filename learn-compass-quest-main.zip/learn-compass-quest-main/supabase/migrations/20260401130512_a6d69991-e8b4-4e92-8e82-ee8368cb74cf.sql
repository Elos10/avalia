
-- Create student_responses table
CREATE TABLE IF NOT EXISTS public.student_responses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  assessment_id UUID NOT NULL REFERENCES public.assessments(id) ON DELETE CASCADE,
  question_id UUID NOT NULL REFERENCES public.assessment_questions(id) ON DELETE CASCADE,
  selected_answer TEXT NOT NULL,
  is_correct BOOLEAN NOT NULL DEFAULT false,
  answered_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(student_id, assessment_id, question_id)
);

-- Create assessment_results table
CREATE TABLE IF NOT EXISTS public.assessment_results (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  assessment_id UUID NOT NULL REFERENCES public.assessments(id) ON DELETE CASCADE,
  total_questions INTEGER NOT NULL DEFAULT 0,
  correct_answers INTEGER NOT NULL DEFAULT 0,
  score_percentage NUMERIC(5,2) NOT NULL DEFAULT 0,
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(student_id, assessment_id)
);

-- Enable RLS
ALTER TABLE public.student_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assessment_results ENABLE ROW LEVEL SECURITY;

-- RLS for student_responses
CREATE POLICY "Admins can manage student responses" ON public.student_responses FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Coordenadores can manage student responses" ON public.student_responses FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'coordenador'));
CREATE POLICY "Authenticated can view student responses" ON public.student_responses FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert student responses" ON public.student_responses FOR INSERT TO authenticated WITH CHECK (true);

-- RLS for assessment_results
CREATE POLICY "Admins can manage assessment results" ON public.assessment_results FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Coordenadores can manage assessment results" ON public.assessment_results FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'coordenador'));
CREATE POLICY "Authenticated can view assessment results" ON public.assessment_results FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can insert assessment results" ON public.assessment_results FOR INSERT TO authenticated WITH CHECK (true);

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.assessment_results;
ALTER PUBLICATION supabase_realtime ADD TABLE public.student_responses;

-- Coordenador permissions on existing tables
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Coordenadores can manage students' AND tablename = 'students') THEN
    CREATE POLICY "Coordenadores can manage students" ON public.students FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'coordenador'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Coordenadores can manage questions' AND tablename = 'questions') THEN
    CREATE POLICY "Coordenadores can manage questions" ON public.questions FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'coordenador'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Coordenadores can manage assessments' AND tablename = 'assessments') THEN
    CREATE POLICY "Coordenadores can manage assessments" ON public.assessments FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'coordenador'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Coordenadores can manage assessment questions' AND tablename = 'assessment_questions') THEN
    CREATE POLICY "Coordenadores can manage assessment questions" ON public.assessment_questions FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'coordenador'));
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE policyname = 'Coordenadores can manage releases' AND tablename = 'assessment_releases') THEN
    CREATE POLICY "Coordenadores can manage releases" ON public.assessment_releases FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'coordenador'));
  END IF;
END $$;
