
-- Allow professors to insert students
CREATE POLICY "Professores can insert students"
ON public.students FOR INSERT
TO authenticated
WITH CHECK (true);

-- Allow professors to update students  
CREATE POLICY "Professores can update students"
ON public.students FOR UPDATE
TO authenticated
USING (true);
