-- Fix overly permissive RLS policies

-- assessment_results: restrict INSERT
DROP POLICY IF EXISTS "Authenticated can insert assessment results" ON public.assessment_results;
CREATE POLICY "Authenticated can insert assessment results"
  ON public.assessment_results FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'coordenador'::app_role)
    OR has_role(auth.uid(), 'professor'::app_role)
  );

-- student_responses: restrict INSERT
DROP POLICY IF EXISTS "Authenticated can insert student responses" ON public.student_responses;
CREATE POLICY "Authenticated can insert student responses"
  ON public.student_responses FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'coordenador'::app_role)
    OR has_role(auth.uid(), 'professor'::app_role)
  );

-- students: restrict INSERT
DROP POLICY IF EXISTS "Professores can insert students" ON public.students;
CREATE POLICY "Authenticated can insert students"
  ON public.students FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'coordenador'::app_role)
    OR has_role(auth.uid(), 'professor'::app_role)
  );

-- students: restrict UPDATE
DROP POLICY IF EXISTS "Professores can update students" ON public.students;
CREATE POLICY "Authenticated can update students"
  ON public.students FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'coordenador'::app_role)
    OR has_role(auth.uid(), 'professor'::app_role)
  );

-- Allow UPDATE on student_responses (for upsert)
CREATE POLICY "Authenticated can update student responses"
  ON public.student_responses FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'coordenador'::app_role)
    OR has_role(auth.uid(), 'professor'::app_role)
  );

-- Allow UPDATE on assessment_results (for upsert)
CREATE POLICY "Authenticated can update assessment results"
  ON public.assessment_results FOR UPDATE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'coordenador'::app_role)
    OR has_role(auth.uid(), 'professor'::app_role)
  );

-- Allow DELETE on assessment_releases (for re-release)
CREATE POLICY "Admins can delete releases"
  ON public.assessment_releases FOR DELETE TO authenticated
  USING (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'coordenador'::app_role)
  );

-- Allow INSERT on assessment_releases
CREATE POLICY "Admins can insert releases"
  ON public.assessment_releases FOR INSERT TO authenticated
  WITH CHECK (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'coordenador'::app_role)
  );